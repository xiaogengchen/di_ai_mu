# !/usr/bin/env python
# -*-coding:utf-8-*-

'''
What is the types and value of y after executing the following code:
x=[1,2,3,4,5] 
y=x[:]
Both x and y are lists. They have the same value, which is [1, 2, 3, 4, 5].
'''

'''
Answer :

y is a list that value is [1,2,3,4,5]
'''