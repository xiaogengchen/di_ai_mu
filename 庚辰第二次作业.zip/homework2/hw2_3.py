# !/usr/bin/env python
# -*-coding:utf-8-*-

'''
What are the types of variables a and b in the following code: 
a=(1)
b=(1,)
'''

'''
Answer :

a is a int value 
b is a tuple
'''