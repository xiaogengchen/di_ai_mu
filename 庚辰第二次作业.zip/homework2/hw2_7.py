# !/usr/bin/env python
# -*-coding:utf-8-*-

'''
内建函数type()是干什么的？type()返回的对象是什么？
'''

'''
内建函数type()用来返回变量的类型，返回的对象是类型对象。
'''