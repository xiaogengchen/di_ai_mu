# !/usr/bin/env python
# -*-coding:utf-8-*-

'''
内建函数str()和repr()之间有什么不同.
'''

'''
答：
str()用于生成一个可读性好、适合打印给用户看的字符串
repr()用于生成一个适合于python内部操作的字符串
'''