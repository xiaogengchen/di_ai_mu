# !/usr/bin/env python
# -*-coding:utf-8-*-

'''
Which of the following are types mutable and which are immutable:
int, list, float, tuple, str.
All the types listed are mutable except for tuple and str.
'''

'''
Answer :

mutable:int、list、float

immutable:tuple、str
'''