#!/usr/bin/python
#-*- coding:utf-8 -*-

'''
11、在空⽩白处填上True或False
p      q       (not p) or q    (p and q) or q     (p or q) and p     (p or q) and (p and q)
True  True
True  False
False True
False False

答：
p      q       (not p) or q    (p and q) or q     (p or q) and p     (p or q) and (p and q)
True  True          True           True                True                  True
True  False         False          False               True                  False
False True          True           True                False                 False
False False         True           False               False                 False
'''
