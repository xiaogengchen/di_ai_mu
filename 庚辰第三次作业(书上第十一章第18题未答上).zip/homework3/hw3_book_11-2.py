# !/usr/bin/env python
# -*-coding:utf-8-*-

'''
结合你对练习 5-2 的解，以便你创建一个带相同对数字并同时返回一它们之和以及
产物的结合函数。
'''


def mySum(num1, num2):
    return num1 + num2


def main():
    print mySum(2, 3)


if __name__ == "__main__":
    main()
